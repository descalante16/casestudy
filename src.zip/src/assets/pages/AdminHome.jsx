import React from "react";
import AdminHeader from "../components/AdminHeader";

function AdminHome() {
  return (
    <div className="bg-orange-400 min-h-screen">
        
        <AdminHeader/>
      
    </div>
  );
}

export default AdminHome;
